# Wiarti Culinary

Website satu halaman statis untuk Wiarti Culinary. Copy utama berbahasa English. Pada kunjungan pertama, situs memilih bahasa berdasarkan preferensi browser untuk English, Bahasa Indonesia, Chinese Simplified atau Traditional, Japanese, Korean, French, dan Spanish. Pengunjung juga dapat memilih bahasa melalui menu; pilihan manual disimpan hanya di browser mereka. Locale yang belum didukung menggunakan English. Terjemahan disertakan secara lokal, tanpa API penerjemahan, database, server, atau layanan email.

Berkas situs berada di akar repositori, sehingga dapat dipilih sebagai sumber GitHub Pages dari branch `main` dan folder `/(root)`. Semua foto situs tersedia secara lokal di folder `assets/` dalam format WebP, termasuk foto chef hasil edit yang digunakan pada bagian Our Story. Halaman memakai path relatif untuk aset sehingga tetap berfungsi di URL proyek GitHub Pages yang memiliki subpath.

Untuk menerbitkan nanti, unggah isi repositori ini ke GitHub, lalu pilih Settings → Pages → Deploy from a branch → `main` → `/(root)`. Tautan publik baru akan tersedia setelah GitHub Pages diaktifkan pada repositori.

Untuk booking, pesan disiapkan di browser sesuai bahasa terpilih dan dibuka langsung ke `https://wa.me/6287718955904`. Website tidak menyimpan data formulir. Tautan Instagram berada di bagian kontak dan footer.
