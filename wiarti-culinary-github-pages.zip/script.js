(() => {
  const catalog = window.WIARTI_TRANSLATIONS || {};
  const supportedLocales = Array.isArray(catalog.locales) ? catalog.locales : ['en'];
  const languageSelect = document.querySelector('#language-select');
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-nav');
  const textSources = new WeakMap();
  const attributeSources = new WeakMap();
  let currentLocale = 'en';
  let currentStrings = {};

  const resolveLocale = (value) => {
    const normalized = String(value || '').replace(/_/g, '-').toLowerCase();
    if (normalized.startsWith('zh')) {
      if (/(hant|tw|hk|mo)/.test(normalized)) return 'zh-TW';
      return 'zh-CN';
    }
    const base = normalized.split('-')[0];
    return supportedLocales.includes(base) ? base : null;
  };

  const chooseInitialLocale = () => {
    try {
      const saved = window.localStorage.getItem('wiarti-language');
      if (saved && supportedLocales.includes(saved)) return saved;
    } catch (_) {}

    const browserPreferences = Array.isArray(navigator.languages) ? navigator.languages : [];
    for (const preference of [...browserPreferences, navigator.language]) {
      const resolved = resolveLocale(preference);
      if (resolved) return resolved;
    }
    return 'en';
  };

  const translated = (key) => currentStrings[key] || key;

  const applyLocale = (locale, persist = false) => {
    currentLocale = supportedLocales.includes(locale) ? locale : 'en';
    currentStrings = catalog.strings?.[currentLocale] || {};

    const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement?.closest('#language-select')) continue;
      if (['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(node.parentElement?.tagName)) continue;
      if (!textSources.has(node)) textSources.set(node, node.nodeValue);
      const original = textSources.get(node);
      const key = original.trim();
      if (!key) continue;
      const leading = original.match(/^\s*/u)?.[0] || '';
      const trailing = original.match(/\s*$/u)?.[0] || '';
      node.nodeValue = leading + translated(key) + trailing;
    }

    document.querySelectorAll('[aria-label], [alt], [placeholder], [title], [content]').forEach((element) => {
      let originals = attributeSources.get(element);
      if (!originals) {
        originals = {};
        attributeSources.set(element, originals);
      }
      ['aria-label', 'alt', 'placeholder', 'title', 'content'].forEach((attribute) => {
        if (!element.hasAttribute(attribute)) return;
        if (!(attribute in originals)) originals[attribute] = element.getAttribute(attribute);
        const key = originals[attribute].trim();
        element.setAttribute(attribute, translated(key));
      });
    });

    document.documentElement.lang = currentLocale;
    if (languageSelect) languageSelect.value = currentLocale;
    if (menuToggle) {
      const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-label', translated(isOpen ? 'Close navigation' : 'Open navigation'));
    }

    if (persist) {
      try {
        window.localStorage.setItem('wiarti-language', currentLocale);
      } catch (_) {}
    }
  };

  const closeMenu = () => {
    menuToggle?.setAttribute('aria-expanded', 'false');
    menuToggle?.setAttribute('aria-label', translated('Open navigation'));
    nav?.classList.remove('is-open');
    document.body.classList.remove('menu-open');
  };

  applyLocale(chooseInitialLocale());

  menuToggle?.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    menuToggle.setAttribute('aria-label', translated(isOpen ? 'Open navigation' : 'Close navigation'));
    nav?.classList.toggle('is-open', !isOpen);
    document.body.classList.toggle('menu-open', !isOpen);
  });

  nav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
  languageSelect?.addEventListener('change', () => {
    applyLocale(languageSelect.value, true);
    if (nav?.classList.contains('is-open')) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeMenu();
  });

  const year = document.querySelector('#year');
  if (year) year.textContent = String(new Date().getFullYear());

  const bookingForm = document.querySelector('#booking-form');
  bookingForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!bookingForm.reportValidity()) return;

    const fields = new FormData(bookingForm);
    const labelFor = (id, fallback) => bookingForm.querySelector(`label[for="${id}"]`)?.textContent.trim() || fallback;
    const selectedText = (id) => bookingForm.querySelector(`#${id}`)?.selectedOptions[0]?.textContent.trim() || '';
    const messageCopy = catalog.messages?.[currentLocale] || catalog.messages?.en || {};
    const message = [
      messageCopy.greeting || 'Hello Wiarti Culinary, I would like to discuss a culinary project.',
      '',
      `${labelFor('client-name', 'Name')}: ${fields.get('name')}`,
      `${labelFor('business-type', 'Business type')}: ${selectedText('business-type')}`,
      `${labelFor('service-type', 'Service of interest')}: ${selectedText('service-type')}`,
      `${labelFor('project-note', 'Project details')}: ${fields.get('details')}`,
      '',
      messageCopy.location || 'I understand Wiarti Culinary is based in Nusa Penida, Bali.'
    ].join('\n');

    const whatsappUrl = `https://wa.me/6287718955904?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  });
})();
